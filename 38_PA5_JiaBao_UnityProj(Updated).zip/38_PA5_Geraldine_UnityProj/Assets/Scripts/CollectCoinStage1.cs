﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CollectCoinStage1 : MonoBehaviour
{
    public int score;
    public Text ScoreText;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Coin")
        {
            Destroy(collision.gameObject);
            score += 1;
            ScoreText.text = "Coins collected : " + score.ToString();
            if (score == 4)
            {
                SceneManager.LoadScene(3);
            }
        }
        else if (collision.gameObject.tag == "Bomb")
        {
            SceneManager.LoadScene(0);
        }
    }
}
