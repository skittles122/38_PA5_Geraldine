﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CollectCoinStage2 : MonoBehaviour
{
    public int score;
    public Text ScoreText;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Coin")
        {
            Destroy(collision.gameObject);
            score += 1;
            ScoreText.text = "Coins collected : " + score.ToString();
            if (score == 8)
            {
                SceneManager.LoadScene(2);
            }
        }
        else if (collision.gameObject.tag == "Bomb")
        {
            SceneManager.LoadScene(0);
        }
    }
}
